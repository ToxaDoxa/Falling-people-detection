# Falling_people_detection > 2023-11-16 11:18pm
https://universe.roboflow.com/toxadoxa-pzaca/falling_people_detection

Provided by a Roboflow user
License: Public Domain

